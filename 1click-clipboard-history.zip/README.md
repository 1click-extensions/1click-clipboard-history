1Click-clipboard-history | https://1ce.org


This extension is an open-source 📰 extension. What is it mean for you:


☑ It's mean it's safe. Everyone can inspect the source code.
☑ It's mean that if you're are a developer or intern your more than welcome to contribute code.

This extension is another extension of 1ce. Our mission is to advance open-source extensions.
Visit our website to learn more, and be part of the community: https://1ce.org

If you have a question, visit the FAQ section on our website: https://1ce.org

Data Usage:

We do not record any of your data usage. Everything stay private on your machine, until your decide you want to share it.